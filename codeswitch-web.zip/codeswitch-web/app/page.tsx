'use client'

import { useState } from 'react'
import CodeEditor from '@/components/CodeEditor'
import LanguageSelect, { LANGUAGES } from '@/components/LanguageSelect'
import FileUpload from '@/components/FileUpload'
import OutputView from '@/components/OutputView'
import { translateCode, type Language } from '@/lib/api'

export default function Home() {
  const [sourceCode, setSourceCode] = useState('')
  const [fromLang, setFromLang] = useState<Language>('python')
  const [toLang, setToLang] = useState<Language>('javascript')
  const [outputCode, setOutputCode] = useState('')
  const [outputNotes, setOutputNotes] = useState<string | undefined>()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [charCount, setCharCount] = useState(0)

  const handleFileContent = (content: string) => {
    setSourceCode(content)
    setCharCount(content.length)
    setOutputCode('')
    setError(null)
  }

  const handleSourceChange = (val: string) => {
    setSourceCode(val)
    setCharCount(val.length)
    if (error) setError(null)
  }

  const handleSwapLanguages = () => {
    setFromLang(toLang)
    setToLang(fromLang)
    if (outputCode) {
      setSourceCode(outputCode)
      setOutputCode('')
    }
  }

  const handleTranslate = async () => {
    if (!sourceCode.trim()) {
      setError('Please paste some code or upload a file first.')
      return
    }
    setIsLoading(true)
    setError(null)
    setOutputCode('')
    setOutputNotes(undefined)

    try {
      const result = await translateCode({
        code: sourceCode,
        from_language: fromLang,
        to_language: toLang,
      })
      setOutputCode(result.translated_code)
      if (result.notes) setOutputNotes(result.notes)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Translation failed. Check your connection.')
    } finally {
      setIsLoading(false)
    }
  }

  const fromLangInfo = LANGUAGES.find(l => l.value === fromLang)
  const toLangInfo = LANGUAGES.find(l => l.value === toLang)

  return (
    <main className="min-h-screen bg-ink relative">
      {/* Background mesh */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-indigo-500/5 rounded-full blur-[80px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

        {/* Header */}
        <header className="mb-10 animate-fade-up">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-lg bg-accent/20 border border-accent/30
              flex items-center justify-center">
              <svg className="w-4 h-4 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <h1 className="font-display text-2xl font-700 text-text tracking-tight"
              style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
              CodeSwitch
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 bg-accent/10 border border-accent/20
              text-accent rounded-full">beta</span>
          </div>
          <p className="text-sm font-mono text-muted max-w-lg">
            Translate source code between programming languages — powered by Wispbyte AI.
          </p>
        </header>

        {/* Language selector bar */}
        <div className="flex items-end gap-3 mb-6 p-4 bg-surface rounded-2xl border border-border
          animate-fade-up" style={{ animationDelay: '0.05s' }}>

          <div className="flex-1">
            <LanguageSelect
              value={fromLang}
              onChange={(lang) => { setFromLang(lang); setOutputCode('') }}
              label="From"
              disabled={isLoading}
            />
          </div>

          {/* Swap button */}
          <button
            onClick={handleSwapLanguages}
            disabled={isLoading}
            title="Swap languages"
            className="flex-none mb-0.5 w-9 h-9 rounded-lg border border-border bg-panel
              flex items-center justify-center text-muted
              hover:border-accent-dim hover:text-accent transition-all duration-200
              disabled:opacity-40 disabled:cursor-not-allowed
              hover:rotate-180 active:scale-90"
            style={{ transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
            </svg>
          </button>

          <div className="flex-1">
            <LanguageSelect
              value={toLang}
              onChange={(lang) => { setToLang(lang); setOutputCode('') }}
              label="To"
              disabled={isLoading}
            />
          </div>

          {/* Translate button */}
          <button
            onClick={handleTranslate}
            disabled={isLoading || !sourceCode.trim()}
            className="flex-none flex items-center gap-2 px-6 py-2.5 mb-0.5
              bg-accent hover:bg-accent/90 active:bg-accent/80
              disabled:bg-accent/30 disabled:cursor-not-allowed
              text-white text-sm font-mono rounded-lg
              transition-all duration-200 shadow-lg shadow-accent/20
              hover:shadow-accent/30 hover:-translate-y-0.5 active:translate-y-0"
          >
            {isLoading ? (
              <>
                <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                translating...
              </>
            ) : (
              <>
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                Translate
              </>
            )}
          </button>
        </div>

        {/* Error banner */}
        {error && (
          <div className="mb-4 flex items-center gap-3 px-4 py-3 bg-red-500/10 border border-red-500/30
            rounded-xl text-sm font-mono text-red-400 animate-fade-up">
            <svg className="w-4 h-4 flex-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {error}
            <button onClick={() => setError(null)} className="ml-auto text-red-400/60 hover:text-red-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}

        {/* Main editor layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 animate-fade-up"
          style={{ animationDelay: '0.1s' }}>

          {/* Input panel */}
          <div className="flex flex-col gap-3 p-4 bg-surface rounded-2xl border border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: fromLangInfo?.color ?? '#7c6fff' }} />
                <span className="text-xs font-mono text-soft uppercase tracking-widest">
                  {fromLangInfo?.label ?? fromLang} source
                </span>
              </div>
              {charCount > 0 && (
                <span className="text-xs font-mono text-muted/60">{charCount.toLocaleString()} chars</span>
              )}
            </div>

            <FileUpload onFileContent={handleFileContent} disabled={isLoading} />

            <div className="flex items-center gap-2 text-xs font-mono text-muted">
              <div className="flex-1 h-px bg-border" />
              or paste below
              <div className="flex-1 h-px bg-border" />
            </div>

            <CodeEditor
              value={sourceCode}
              onChange={handleSourceChange}
              placeholder={`// Paste your ${fromLangInfo?.label ?? fromLang} code here...\n// or upload a file above`}
              disabled={isLoading}
              onClear={() => { setSourceCode(''); setCharCount(0); setOutputCode('') }}
            />
          </div>

          {/* Output panel */}
          <div className="flex flex-col gap-3 p-4 bg-surface rounded-2xl border border-border">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: toLangInfo?.color ?? '#7c6fff' }} />
              <span className="text-xs font-mono text-soft uppercase tracking-widest">
                {toLangInfo?.label ?? toLang} output
              </span>
            </div>
            <OutputView
              code={outputCode}
              language={toLang}
              notes={outputNotes}
              isLoading={isLoading}
            />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-8 text-center animate-fade-up" style={{ animationDelay: '0.15s' }}>
          <p className="text-xs font-mono text-muted/50">
            powered by{' '}
            <span className="text-accent/60">Wispbyte AI</span>
            {' '}· {LANGUAGES.length} languages supported
          </p>
        </footer>
      </div>
    </main>
  )
}
