'use client'

import { useState } from 'react'
import { type Language } from '@/lib/api'
import { LANGUAGES } from './LanguageSelect'

interface OutputViewProps {
  code: string
  language: Language
  notes?: string
  isLoading?: boolean
}

export default function OutputView({ code, language, notes, isLoading }: OutputViewProps) {
  const [copied, setCopied] = useState(false)

  const langInfo = LANGUAGES.find(l => l.value === language)
  const lineCount = code ? code.split('\n').length : 0

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const ext = langInfo?.ext ?? 'txt'
    const blob = new Blob([code], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `translated.${ext}`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (isLoading) {
    return (
      <div className="flex flex-col gap-2 h-full animate-fade-up">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-soft uppercase tracking-widest">Output</span>
        </div>
        <div className="flex-1 rounded-xl border border-border bg-panel overflow-hidden">
          <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-border bg-surface">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/40" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/40" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/40" />
            <span className="ml-auto text-xs font-mono text-muted animate-pulse">translating...</span>
          </div>
          <div className="p-4 space-y-2.5">
            {[100, 80, 90, 60, 75, 85, 50].map((w, i) => (
              <div
                key={i}
                className="h-3 rounded shimmer-bg"
                style={{ width: `${w}%`, animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (!code) {
    return (
      <div className="flex flex-col gap-2 h-full">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-soft uppercase tracking-widest">Output</span>
        </div>
        <div className="flex-1 rounded-xl border border-border border-dashed bg-panel/50
          flex flex-col items-center justify-center gap-3 text-center p-8">
          <div className="w-12 h-12 rounded-xl bg-panel border border-border
            flex items-center justify-center">
            <svg className="w-5 h-5 text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-mono text-muted">Translated code will appear here</p>
            <p className="text-xs text-muted/60 mt-1">Paste code and click Translate</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-2 h-full animate-fade-up">
      <div className="flex items-center justify-between">
        <span className="text-xs font-mono text-soft uppercase tracking-widest">Output</span>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-muted">{lineCount} lines</span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono
              bg-panel border border-border rounded-lg text-soft
              hover:border-accent-dim hover:text-text transition-all duration-200"
          >
            {copied ? (
              <>
                <svg className="w-3 h-3 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span className="text-green-400">copied!</span>
              </>
            ) : (
              <>
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                copy
              </>
            )}
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono
              bg-accent/10 border border-accent/30 rounded-lg text-accent
              hover:bg-accent/20 hover:border-accent/50 transition-all duration-200"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            .{langInfo?.ext ?? 'txt'}
          </button>
        </div>
      </div>

      <div className="flex-1 rounded-xl border border-border bg-panel overflow-hidden glow-accent">
        {/* Terminal header */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-border bg-surface">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500/40" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/40" />
          <span className="w-2.5 h-2.5 rounded-full bg-green-500/40" />
          <span className="ml-3 text-xs font-mono px-2 py-0.5 bg-accent/10 text-accent rounded border border-accent/20">
            {langInfo?.label ?? language}
          </span>
          <span className="ml-auto text-xs font-mono text-green-400/60">✓ translated</span>
        </div>

        {/* Code output */}
        <div className="flex overflow-auto" style={{ maxHeight: '480px' }}>
          {/* Line numbers */}
          <div className="flex-none py-3 pl-4 pr-3 text-xs font-mono text-muted/40 text-right select-none
            border-r border-border bg-surface/50 leading-[1.7]"
            style={{ minWidth: '3rem' }}>
            {code.split('\n').map((_, i) => (
              <div key={i}>{i + 1}</div>
            ))}
          </div>
          <pre className="flex-1 p-3 text-sm font-mono text-text leading-[1.7] overflow-x-auto whitespace-pre">
            {code}
          </pre>
        </div>
      </div>

      {/* Notes from AI */}
      {notes && (
        <div className="rounded-lg border border-border bg-panel/50 p-3 flex gap-2.5">
          <svg className="w-4 h-4 text-accent/70 flex-none mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-xs font-mono text-soft leading-relaxed">{notes}</p>
        </div>
      )}
    </div>
  )
}
