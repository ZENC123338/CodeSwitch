'use client'

import { type Language } from '@/lib/api'

export const LANGUAGES: { value: Language; label: string; ext: string; color: string }[] = [
  { value: 'python',     label: 'Python',      ext: 'py',    color: '#3b82f6' },
  { value: 'javascript', label: 'JavaScript',  ext: 'js',    color: '#f59e0b' },
  { value: 'typescript', label: 'TypeScript',  ext: 'ts',    color: '#3b82f6' },
  { value: 'java',       label: 'Java',        ext: 'java',  color: '#ef4444' },
  { value: 'cpp',        label: 'C++',         ext: 'cpp',   color: '#8b5cf6' },
  { value: 'c',          label: 'C',           ext: 'c',     color: '#6366f1' },
  { value: 'csharp',     label: 'C#',          ext: 'cs',    color: '#10b981' },
  { value: 'go',         label: 'Go',          ext: 'go',    color: '#06b6d4' },
  { value: 'rust',       label: 'Rust',        ext: 'rs',    color: '#f97316' },
  { value: 'php',        label: 'PHP',         ext: 'php',   color: '#a78bfa' },
  { value: 'ruby',       label: 'Ruby',        ext: 'rb',    color: '#f43f5e' },
  { value: 'swift',      label: 'Swift',       ext: 'swift', color: '#f97316' },
  { value: 'kotlin',     label: 'Kotlin',      ext: 'kt',    color: '#a855f7' },
  { value: 'r',          label: 'R',           ext: 'r',     color: '#3b82f6' },
  { value: 'scala',      label: 'Scala',       ext: 'scala', color: '#ef4444' },
  { value: 'dart',       label: 'Dart',        ext: 'dart',  color: '#06b6d4' },
  { value: 'lua',        label: 'Lua',         ext: 'lua',   color: '#6366f1' },
  { value: 'perl',       label: 'Perl',        ext: 'pl',    color: '#84cc16' },
  { value: 'haskell',    label: 'Haskell',     ext: 'hs',    color: '#8b5cf6' },
  { value: 'elixir',     label: 'Elixir',      ext: 'ex',    color: '#a78bfa' },
  { value: 'bash',       label: 'Bash',        ext: 'sh',    color: '#22c55e' },
]

interface LanguageSelectProps {
  value: Language
  onChange: (lang: Language) => void
  label: string
  disabled?: boolean
}

export default function LanguageSelect({ value, onChange, label, disabled }: LanguageSelectProps) {
  const selected = LANGUAGES.find(l => l.value === value)

  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-mono text-soft uppercase tracking-widest">{label}</label>
      <div className="relative">
        {/* Color dot */}
        <span
          className="absolute left-3 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full transition-colors duration-300"
          style={{ backgroundColor: selected?.color ?? '#7c6fff' }}
        />
        <select
          value={value}
          onChange={e => onChange(e.target.value as Language)}
          disabled={disabled}
          className="
            w-full pl-8 pr-8 py-2.5
            bg-panel border border-border rounded-lg
            font-mono text-sm text-text
            appearance-none cursor-pointer
            transition-all duration-200
            hover:border-accent-dim focus:border-accent
            disabled:opacity-50 disabled:cursor-not-allowed
          "
        >
          {LANGUAGES.map(lang => (
            <option key={lang.value} value={lang.value}>
              {lang.label}
            </option>
          ))}
        </select>
        {/* Chevron */}
        <svg
          className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted pointer-events-none"
          fill="none" stroke="currentColor" viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </div>
  )
}
