'use client'

import { useRef } from 'react'

interface CodeEditorProps {
  value: string
  onChange: (val: string) => void
  placeholder?: string
  disabled?: boolean
  label?: string
  language?: string
  onClear?: () => void
}

export default function CodeEditor({
  value, onChange, placeholder, disabled, label, language, onClear
}: CodeEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const lineCount = value ? value.split('\n').length : 1

  // Handle Tab key
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault()
      const start = e.currentTarget.selectionStart
      const end = e.currentTarget.selectionEnd
      const newVal = value.substring(0, start) + '  ' + value.substring(end)
      onChange(newVal)
      // restore cursor
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = start + 2
          textareaRef.current.selectionEnd = start + 2
        }
      }, 0)
    }
  }

  return (
    <div className="flex flex-col gap-2 h-full">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        {label && (
          <span className="text-xs font-mono text-soft uppercase tracking-widest">{label}</span>
        )}
        <div className="flex items-center gap-3 ml-auto">
          {language && (
            <span className="text-xs font-mono text-muted px-2 py-0.5 bg-panel rounded border border-border">
              {language}
            </span>
          )}
          {value && onClear && (
            <button
              onClick={onClear}
              disabled={disabled}
              className="text-xs font-mono text-muted hover:text-soft transition-colors"
            >
              clear
            </button>
          )}
          {value && (
            <span className="text-xs font-mono text-muted">
              {lineCount} {lineCount === 1 ? 'line' : 'lines'}
            </span>
          )}
        </div>
      </div>

      {/* Editor wrapper with line numbers */}
      <div className="relative flex-1 rounded-xl border border-border bg-panel overflow-hidden
        focus-within:border-accent-dim transition-colors duration-200 group">

        {/* Terminal dots decoration */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-border bg-surface">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500/40" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/40" />
          <span className="w-2.5 h-2.5 rounded-full bg-green-500/40" />
        </div>

        <div className="flex" style={{ minHeight: '200px' }}>
          {/* Line numbers */}
          <div
            className="flex-none py-3 pl-4 pr-3 text-xs font-mono text-muted/50 text-right select-none
              border-r border-border bg-surface/50 leading-[1.7]"
            style={{ minWidth: '3rem' }}
            aria-hidden="true"
          >
            {Array.from({ length: Math.max(lineCount, 8) }, (_, i) => (
              <div key={i + 1}>{i + 1}</div>
            ))}
          </div>

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            value={value}
            onChange={e => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            disabled={disabled}
            spellCheck={false}
            autoCorrect="off"
            autoCapitalize="off"
            className="
              flex-1 code-area p-3 text-sm font-mono text-text leading-[1.7]
              bg-transparent resize-none w-full
              placeholder:text-muted/40
              disabled:opacity-50 disabled:cursor-not-allowed
            "
          />
        </div>
      </div>
    </div>
  )
}
