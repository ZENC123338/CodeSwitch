'use client'

import { useRef, useState } from 'react'

interface FileUploadProps {
  onFileContent: (content: string, filename: string) => void
  disabled?: boolean
}

export default function FileUpload({ onFileContent, disabled }: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [filename, setFilename] = useState<string | null>(null)

  const handleFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const text = e.target?.result as string
      onFileContent(text, file.name)
      setFilename(file.name)
    }
    reader.readAsText(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    if (disabled) return
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
  }

  return (
    <div
      onDrop={handleDrop}
      onDragOver={e => { e.preventDefault(); setIsDragging(true) }}
      onDragLeave={() => setIsDragging(false)}
      onClick={() => !disabled && inputRef.current?.click()}
      className={`
        relative flex flex-col items-center justify-center gap-2
        border-2 border-dashed rounded-xl p-5 cursor-pointer
        transition-all duration-200 group select-none
        ${isDragging
          ? 'border-accent bg-accent/5 scale-[1.01]'
          : 'border-border hover:border-accent-dim hover:bg-white/[0.02]'
        }
        ${disabled ? 'opacity-40 cursor-not-allowed' : ''}
      `}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".py,.js,.ts,.java,.cpp,.c,.cs,.go,.rs,.php,.rb,.swift,.kt,.r,.scala,.dart,.lua,.pl,.hs,.ex,.sh,.txt"
        onChange={handleChange}
        disabled={disabled}
        className="hidden"
      />

      {/* Upload icon */}
      <div className={`
        w-10 h-10 rounded-lg flex items-center justify-center
        transition-colors duration-200
        ${isDragging ? 'bg-accent/20' : 'bg-panel group-hover:bg-accent/10'}
      `}>
        <svg className={`w-5 h-5 transition-colors ${isDragging ? 'text-accent' : 'text-muted group-hover:text-accent-dim'}`}
          fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
      </div>

      {filename ? (
        <div className="text-center">
          <p className="text-xs font-mono text-accent truncate max-w-[180px]">{filename}</p>
          <p className="text-xs text-muted mt-0.5">Click to replace</p>
        </div>
      ) : (
        <div className="text-center">
          <p className="text-xs font-mono text-soft">Drop file or click</p>
          <p className="text-xs text-muted mt-0.5">.py .js .ts .go .rs + more</p>
        </div>
      )}
    </div>
  )
}
