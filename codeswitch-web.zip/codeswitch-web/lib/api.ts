const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://212.132.99.151:11064'

export type Language =
  | 'python'
  | 'javascript'
  | 'typescript'
  | 'java'
  | 'cpp'
  | 'c'
  | 'csharp'
  | 'go'
  | 'rust'
  | 'php'
  | 'ruby'
  | 'swift'
  | 'kotlin'
  | 'r'
  | 'scala'
  | 'dart'
  | 'lua'
  | 'perl'
  | 'haskell'
  | 'elixir'
  | 'bash'

export interface TranslateRequest {
  code: string
  from_language: Language
  to_language: Language
}

export interface TranslateResponse {
  translated_code: string
  from_language: string
  to_language: string
  notes?: string
  error?: string
}

export async function translateCode(req: TranslateRequest): Promise<TranslateResponse> {
  const res = await fetch(`${API_BASE}/translate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(req),
  })

  if (!res.ok) {
    let errMsg = `Server error: ${res.status}`
    try {
      const body = await res.json()
      errMsg = body?.detail || body?.error || errMsg
    } catch {}
    throw new Error(errMsg)
  }

  return res.json()
}

export async function healthCheck(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/health`, { method: 'GET' })
    return res.ok
  } catch {
    return false
  }
}
